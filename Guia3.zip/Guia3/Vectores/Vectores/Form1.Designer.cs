﻿namespace Vectores
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Iblnumero = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.btAgregar = new System.Windows.Forms.Button();
            this.btOrdenada = new System.Windows.Forms.Button();
            this.Istdesorden = new System.Windows.Forms.ListBox();
            this.IstOrdenar = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Iblnumero
            // 
            this.Iblnumero.AutoSize = true;
            this.Iblnumero.Location = new System.Drawing.Point(19, 61);
            this.Iblnumero.Name = "Iblnumero";
            this.Iblnumero.Size = new System.Drawing.Size(88, 13);
            this.Iblnumero.TabIndex = 0;
            this.Iblnumero.Text = "Ingresar Numero:";
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(107, 58);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(100, 20);
            this.txtNum.TabIndex = 1;
            // 
            // btAgregar
            // 
            this.btAgregar.Location = new System.Drawing.Point(240, 52);
            this.btAgregar.Name = "btAgregar";
            this.btAgregar.Size = new System.Drawing.Size(75, 23);
            this.btAgregar.TabIndex = 2;
            this.btAgregar.Text = "Agregar";
            this.btAgregar.UseVisualStyleBackColor = true;
            this.btAgregar.Click += new System.EventHandler(this.btAgregar_Click);
            // 
            // btOrdenada
            // 
            this.btOrdenada.Location = new System.Drawing.Point(242, 103);
            this.btOrdenada.Name = "btOrdenada";
            this.btOrdenada.Size = new System.Drawing.Size(75, 23);
            this.btOrdenada.TabIndex = 3;
            this.btOrdenada.Text = "Ordenar";
            this.btOrdenada.UseVisualStyleBackColor = true;
            this.btOrdenada.Click += new System.EventHandler(this.btOrdenar_Click);
            // 
            // Istdesorden
            // 
            this.Istdesorden.FormattingEnabled = true;
            this.Istdesorden.Location = new System.Drawing.Point(38, 172);
            this.Istdesorden.Name = "Istdesorden";
            this.Istdesorden.Size = new System.Drawing.Size(120, 134);
            this.Istdesorden.TabIndex = 4;
            // 
            // IstOrdenar
            // 
            this.IstOrdenar.FormattingEnabled = true;
            this.IstOrdenar.Location = new System.Drawing.Point(201, 172);
            this.IstOrdenar.Name = "IstOrdenar";
            this.IstOrdenar.Size = new System.Drawing.Size(120, 134);
            this.IstOrdenar.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(369, 352);
            this.Controls.Add(this.IstOrdenar);
            this.Controls.Add(this.Istdesorden);
            this.Controls.Add(this.btOrdenada);
            this.Controls.Add(this.btAgregar);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.Iblnumero);
            this.Name = "Form1";
            this.Text = "Ordenar";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Iblnumero;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button btAgregar;
        private System.Windows.Forms.Button btOrdenada;
        private System.Windows.Forms.ListBox Istdesorden;
        private System.Windows.Forms.ListBox IstOrdenar;
    }
}

