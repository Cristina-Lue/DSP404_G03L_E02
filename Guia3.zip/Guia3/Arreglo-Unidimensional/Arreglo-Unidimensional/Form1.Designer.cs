﻿namespace Arreglo_Unidimensional
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Iblnumero = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.btAgregar = new System.Windows.Forms.Button();
            this.btOrdenar = new System.Windows.Forms.Button();
            this.Istdesorden = new System.Windows.Forms.ListBox();
            this.IstOrdenada = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Iblnumero
            // 
            this.Iblnumero.AutoSize = true;
            this.Iblnumero.Location = new System.Drawing.Point(21, 44);
            this.Iblnumero.Name = "Iblnumero";
            this.Iblnumero.Size = new System.Drawing.Size(107, 16);
            this.Iblnumero.TabIndex = 0;
            this.Iblnumero.Text = "Ingresar número:";
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(134, 41);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(100, 22);
            this.txtNum.TabIndex = 1;
            // 
            // btAgregar
            // 
            this.btAgregar.Location = new System.Drawing.Point(291, 40);
            this.btAgregar.Name = "btAgregar";
            this.btAgregar.Size = new System.Drawing.Size(75, 23);
            this.btAgregar.TabIndex = 2;
            this.btAgregar.Text = "Agregar";
            this.btAgregar.UseVisualStyleBackColor = true;
            this.btAgregar.Click += new System.EventHandler(this.btAgregar_Click);
            // 
            // btOrdenar
            // 
            this.btOrdenar.Location = new System.Drawing.Point(291, 105);
            this.btOrdenar.Name = "btOrdenar";
            this.btOrdenar.Size = new System.Drawing.Size(75, 23);
            this.btOrdenar.TabIndex = 3;
            this.btOrdenar.Text = "Ordenar";
            this.btOrdenar.UseVisualStyleBackColor = true;
            this.btOrdenar.Click += new System.EventHandler(this.btOrdenar_Click);
            // 
            // Istdesorden
            // 
            this.Istdesorden.FormattingEnabled = true;
            this.Istdesorden.ItemHeight = 16;
            this.Istdesorden.Location = new System.Drawing.Point(77, 190);
            this.Istdesorden.Name = "Istdesorden";
            this.Istdesorden.Size = new System.Drawing.Size(120, 196);
            this.Istdesorden.TabIndex = 4;
            // 
            // IstOrdenada
            // 
            this.IstOrdenada.FormattingEnabled = true;
            this.IstOrdenada.ItemHeight = 16;
            this.IstOrdenada.Location = new System.Drawing.Point(246, 190);
            this.IstOrdenada.Name = "IstOrdenada";
            this.IstOrdenada.Size = new System.Drawing.Size(120, 196);
            this.IstOrdenada.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(439, 440);
            this.Controls.Add(this.IstOrdenada);
            this.Controls.Add(this.Istdesorden);
            this.Controls.Add(this.btOrdenar);
            this.Controls.Add(this.btAgregar);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.Iblnumero);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Iblnumero;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button btAgregar;
        private System.Windows.Forms.Button btOrdenar;
        private System.Windows.Forms.ListBox Istdesorden;
        private System.Windows.Forms.ListBox IstOrdenada;
    }
}

