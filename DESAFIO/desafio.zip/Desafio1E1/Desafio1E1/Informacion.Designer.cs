﻿namespace Desafio1E1
{
    partial class Informacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Informacion));
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tableLayoutPanel3 = new TableLayoutPanel();
            pictureBox3 = new PictureBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            tableLayoutPanel2 = new TableLayoutPanel();
            pictureBox2 = new PictureBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            pictureBox1 = new PictureBox();
            textBox1 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            tabPage2 = new TabPage();
            tableLayoutPanel6 = new TableLayoutPanel();
            pictureBox6 = new PictureBox();
            textBox16 = new TextBox();
            textBox14 = new TextBox();
            textBox18 = new TextBox();
            tableLayoutPanel5 = new TableLayoutPanel();
            pictureBox5 = new PictureBox();
            textBox13 = new TextBox();
            textBox15 = new TextBox();
            textBox17 = new TextBox();
            tableLayoutPanel4 = new TableLayoutPanel();
            pictureBox4 = new PictureBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            tabPage3 = new TabPage();
            tableLayoutPanel9 = new TableLayoutPanel();
            textBox23 = new TextBox();
            pictureBox9 = new PictureBox();
            textBox24 = new TextBox();
            tableLayoutPanel8 = new TableLayoutPanel();
            textBox21 = new TextBox();
            pictureBox8 = new PictureBox();
            textBox22 = new TextBox();
            tableLayoutPanel7 = new TableLayoutPanel();
            textBox19 = new TextBox();
            pictureBox7 = new PictureBox();
            textBox20 = new TextBox();
            panelGrafico = new TabPage();
            cartesianChart1 = new LiveCharts.WinForms.CartesianChart();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            tabPage3.SuspendLayout();
            tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panelGrafico.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(panelGrafico);
            tabControl1.Location = new Point(4, 2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(826, 501);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(tableLayoutPanel3);
            tabPage1.Controls.Add(tableLayoutPanel2);
            tabPage1.Controls.Add(tableLayoutPanel1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(818, 473);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "PROGRAMAS DE ENTRETENIMIENTO";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 29.4554462F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70.5445557F));
            tableLayoutPanel3.Controls.Add(pictureBox3, 0, 1);
            tableLayoutPanel3.Controls.Add(textBox7, 0, 0);
            tableLayoutPanel3.Controls.Add(textBox8, 1, 0);
            tableLayoutPanel3.Controls.Add(textBox9, 1, 1);
            tableLayoutPanel3.Location = new Point(495, 43);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 46.11111F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 53.88889F));
            tableLayoutPanel3.Size = new Size(315, 360);
            tableLayoutPanel3.TabIndex = 1;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 169);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(86, 108);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(3, 3);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(86, 160);
            textBox7.TabIndex = 1;
            textBox7.Text = "\r\n\r\nTHE MARVELOUS MRS. MAISEL\r\n(LA MARAVILLOSA SEÑORA MAISEL)";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(95, 3);
            textBox8.Multiline = true;
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(217, 160);
            textBox8.TabIndex = 2;
            textBox8.Text = "Creador:  Amy Sherman-Palladino\r\nProtagonistas:  -Rachel Brosnahan,  -Michael Zegen,  -Alex Borstein,  -Tony Shalho,  -Marin Hinkle.\r\nPais de origen:  Estados Unidos\r\nTemporadas:  3\r\nEpisodios:  26";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(95, 169);
            textBox9.Multiline = true;
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(217, 188);
            textBox9.TabIndex = 3;
            textBox9.Text = resources.GetString("textBox9.Text");
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 29.4554462F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70.5445557F));
            tableLayoutPanel2.Controls.Add(pictureBox2, 0, 1);
            tableLayoutPanel2.Controls.Add(textBox4, 0, 0);
            tableLayoutPanel2.Controls.Add(textBox5, 1, 0);
            tableLayoutPanel2.Controls.Add(textBox6, 1, 1);
            tableLayoutPanel2.Location = new Point(15, 258);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(477, 209);
            tableLayoutPanel2.TabIndex = 1;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 107);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(127, 76);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(3, 3);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(134, 98);
            textBox4.TabIndex = 1;
            textBox4.Text = "\r\n\r\nCHERNOBYL\r\n(CHERNÓBIL)";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(143, 3);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(331, 98);
            textBox5.TabIndex = 2;
            textBox5.Text = "Creador:  Craig Mazin\r\nProtagonistas:  -Jared Harris,  -Stellan Skarsgárd,  -Emily Watson.\r\nPais de origen:  Estados Unidos,  -Reino Unido\r\nTemporadas:  1\r\nEpisodios:  5\r\n\r\n";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(143, 107);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(328, 99);
            textBox6.TabIndex = 3;
            textBox6.Text = resources.GetString("textBox6.Text");
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 29.4554462F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70.5445557F));
            tableLayoutPanel1.Controls.Add(pictureBox1, 0, 1);
            tableLayoutPanel1.Controls.Add(textBox1, 1, 0);
            tableLayoutPanel1.Controls.Add(textBox3, 1, 1);
            tableLayoutPanel1.Controls.Add(textBox2, 0, 0);
            tableLayoutPanel1.Location = new Point(15, 6);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 58.636364F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 41.363636F));
            tableLayoutPanel1.Size = new Size(474, 246);
            tableLayoutPanel1.TabIndex = 0;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 147);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(127, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(142, 3);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(329, 138);
            textBox1.TabIndex = 4;
            textBox1.Text = resources.GetString("textBox1.Text");
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(142, 147);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(329, 96);
            textBox3.TabIndex = 5;
            textBox3.Text = resources.GetString("textBox3.Text");
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(3, 3);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(133, 138);
            textBox2.TabIndex = 3;
            textBox2.Text = "\r\n\r\n\r\nGAME OF THRONES\r\n(JUEGO DE TRONOS)";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(tableLayoutPanel6);
            tabPage2.Controls.Add(tableLayoutPanel5);
            tabPage2.Controls.Add(tableLayoutPanel4);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(818, 473);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "LIBROS";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 2;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44.0366974F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55.9633026F));
            tableLayoutPanel6.Controls.Add(pictureBox6, 0, 1);
            tableLayoutPanel6.Controls.Add(textBox16, 0, 0);
            tableLayoutPanel6.Controls.Add(textBox14, 1, 0);
            tableLayoutPanel6.Controls.Add(textBox18, 1, 1);
            tableLayoutPanel6.Location = new Point(515, 87);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 2;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 28.9552231F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 71.04478F));
            tableLayoutPanel6.Size = new Size(297, 335);
            tableLayoutPanel6.TabIndex = 2;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 100);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(124, 173);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 0;
            pictureBox6.TabStop = false;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(3, 3);
            textBox16.Multiline = true;
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(124, 91);
            textBox16.TabIndex = 1;
            textBox16.Text = "\r\n\r\n\r\nPERRY MASON";
            // 
            // textBox14
            // 
            textBox14.Location = new Point(133, 3);
            textBox14.Multiline = true;
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(161, 91);
            textBox14.TabIndex = 2;
            textBox14.Text = "Autor: Erle Stanley Gardner.          \r\nGénero: Novela policiaca.\r\n \r\nProtagonistas:  Perry Mason";
            // 
            // textBox18
            // 
            textBox18.Location = new Point(133, 100);
            textBox18.Multiline = true;
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(161, 232);
            textBox18.TabIndex = 3;
            textBox18.Text = resources.GetString("textBox18.Text");
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 2;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 29.8097248F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70.19028F));
            tableLayoutPanel5.Controls.Add(pictureBox5, 0, 1);
            tableLayoutPanel5.Controls.Add(textBox13, 0, 0);
            tableLayoutPanel5.Controls.Add(textBox15, 1, 1);
            tableLayoutPanel5.Controls.Add(textBox17, 1, 0);
            tableLayoutPanel5.Location = new Point(6, 309);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 2;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 45.3416138F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 54.6583862F));
            tableLayoutPanel5.Size = new Size(483, 161);
            tableLayoutPanel5.TabIndex = 1;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(3, 76);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(137, 82);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(3, 3);
            textBox13.Multiline = true;
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(137, 67);
            textBox13.TabIndex = 1;
            textBox13.Text = "\r\n\r\nGOOSEBUMPS";
            // 
            // textBox15
            // 
            textBox15.Location = new Point(146, 76);
            textBox15.Multiline = true;
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(334, 82);
            textBox15.TabIndex = 3;
            textBox15.Text = resources.GetString("textBox15.Text");
            // 
            // textBox17
            // 
            textBox17.Location = new Point(146, 3);
            textBox17.Multiline = true;
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(334, 67);
            textBox17.TabIndex = 4;
            textBox17.Text = resources.GetString("textBox17.Text");
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26.4270611F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 73.57294F));
            tableLayoutPanel4.Controls.Add(pictureBox4, 0, 1);
            tableLayoutPanel4.Controls.Add(textBox10, 0, 0);
            tableLayoutPanel4.Controls.Add(textBox11, 1, 0);
            tableLayoutPanel4.Controls.Add(textBox12, 1, 1);
            tableLayoutPanel4.Location = new Point(6, 6);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 2;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 40.89347F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 59.10653F));
            tableLayoutPanel4.Size = new Size(483, 300);
            tableLayoutPanel4.TabIndex = 0;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 125);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(117, 107);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(3, 3);
            textBox10.Multiline = true;
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(121, 103);
            textBox10.TabIndex = 1;
            textBox10.Text = "\r\n\r\nHARRY POTTER";
            // 
            // textBox11
            // 
            textBox11.Location = new Point(130, 3);
            textBox11.Multiline = true;
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(350, 115);
            textBox11.TabIndex = 2;
            textBox11.Text = resources.GetString("textBox11.Text");
            // 
            // textBox12
            // 
            textBox12.Location = new Point(130, 125);
            textBox12.Multiline = true;
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(350, 172);
            textBox12.TabIndex = 3;
            textBox12.Text = resources.GetString("textBox12.Text");
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(tableLayoutPanel9);
            tabPage3.Controls.Add(tableLayoutPanel8);
            tabPage3.Controls.Add(tableLayoutPanel7);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(818, 473);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "LENGUAJES DE PROGRAMACION";
            tabPage3.UseVisualStyleBackColor = true;
            tabPage3.Click += tabPage3_Click;
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.ColumnCount = 2;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Controls.Add(textBox23, 0, 0);
            tableLayoutPanel9.Controls.Add(pictureBox9, 0, 1);
            tableLayoutPanel9.Controls.Add(textBox24, 1, 1);
            tableLayoutPanel9.Location = new Point(555, 19);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 2;
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Size = new Size(242, 371);
            tableLayoutPanel9.TabIndex = 2;
            // 
            // textBox23
            // 
            textBox23.Location = new Point(3, 3);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(100, 23);
            textBox23.TabIndex = 1;
            textBox23.Text = "JAVASCRIPT";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(3, 31);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(115, 142);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 1;
            pictureBox9.TabStop = false;
            // 
            // textBox24
            // 
            textBox24.Location = new Point(124, 31);
            textBox24.Multiline = true;
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(115, 337);
            textBox24.TabIndex = 1;
            textBox24.Text = resources.GetString("textBox24.Text");
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.ColumnCount = 2;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.Controls.Add(textBox21, 0, 0);
            tableLayoutPanel8.Controls.Add(pictureBox8, 0, 1);
            tableLayoutPanel8.Controls.Add(textBox22, 1, 1);
            tableLayoutPanel8.Location = new Point(288, 19);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 2;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel8.Size = new Size(242, 371);
            tableLayoutPanel8.TabIndex = 1;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(3, 3);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(100, 23);
            textBox21.TabIndex = 1;
            textBox21.Text = "JAVA";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(3, 31);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(115, 142);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 1;
            pictureBox8.TabStop = false;
            // 
            // textBox22
            // 
            textBox22.Location = new Point(124, 31);
            textBox22.Multiline = true;
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(115, 337);
            textBox22.TabIndex = 1;
            textBox22.Text = resources.GetString("textBox22.Text");
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 2;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.Controls.Add(textBox19, 0, 0);
            tableLayoutPanel7.Controls.Add(pictureBox7, 0, 1);
            tableLayoutPanel7.Controls.Add(textBox20, 1, 1);
            tableLayoutPanel7.Location = new Point(19, 16);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 2;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.Size = new Size(242, 371);
            tableLayoutPanel7.TabIndex = 0;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(3, 3);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(100, 23);
            textBox19.TabIndex = 1;
            textBox19.Text = "PYTHON";
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 31);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(115, 142);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 1;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(124, 31);
            textBox20.Multiline = true;
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(115, 337);
            textBox20.TabIndex = 1;
            textBox20.Text = resources.GetString("textBox20.Text");
            // 
            // panelGrafico
            // 
            panelGrafico.Controls.Add(cartesianChart1);
            panelGrafico.Location = new Point(4, 24);
            panelGrafico.Name = "panelGrafico";
            panelGrafico.Padding = new Padding(3);
            panelGrafico.Size = new Size(818, 473);
            panelGrafico.TabIndex = 3;
            panelGrafico.Text = "ESTADISTICA DE RESULTADOS";
            panelGrafico.UseVisualStyleBackColor = true;
            panelGrafico.Click += tabPage4_Click;
            // 
            // cartesianChart1
            // 
            cartesianChart1.ForeColor = SystemColors.AppWorkspace;
            cartesianChart1.Location = new Point(67, 40);
            cartesianChart1.Name = "cartesianChart1";
            cartesianChart1.Size = new Size(252, 139);
            cartesianChart1.TabIndex = 0;
            cartesianChart1.Text = "cartesianChart1";
            cartesianChart1.ChildChanged += cartesianChart1_ChildChanged;
            // 
            // Informacion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(830, 505);
            Controls.Add(tabControl1);
            Name = "Informacion";
            Text = "Informacion";
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            tabPage3.ResumeLayout(false);
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panelGrafico.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage panelGrafico;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel1;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox7;
        private TextBox textBox6;
        private TextBox textBox8;
        private TextBox textBox9;
        private TableLayoutPanel tableLayoutPanel6;
        private TableLayoutPanel tableLayoutPanel5;
        private TableLayoutPanel tableLayoutPanel4;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TableLayoutPanel tableLayoutPanel7;
        private TextBox textBox19;
        private PictureBox pictureBox7;
        private TextBox textBox20;
        private TableLayoutPanel tableLayoutPanel8;
        private TextBox textBox21;
        private PictureBox pictureBox8;
        private TextBox textBox22;
        private TableLayoutPanel tableLayoutPanel9;
        private TextBox textBox23;
        private PictureBox pictureBox9;
        private TextBox textBox24;
        private LiveCharts.WinForms.CartesianChart cartesianChart1;
    }
}